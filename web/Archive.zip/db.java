
/* Introduction 
  ==============
 *db Class
 *This class is used for database related (connect, insert, update, and delete) operations , 
* It aims to facilitate the  use of CRUD functions every where they are needed in the project and to avoid multiple CRUD lines of code. 
* by calling this class you can access the databases
 * @author    Kaghusa  Boniface  Mutanava 
*/

package core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Set;

public class db 
{
    // General Attributes  for database related operations 
   
    
    public Connection con=null;
    public String Username="root";
    public String Passwword="";
    public  Statement Stmt=null;
    public  PreparedStatement psmt=null;
    public  String Url="jdbc:mysql://127.0.0.1:3307/struct?useUnicode=yes&characterEncoding=UTF-8";
    public String  SQL="";
    
    // function to get the Database cannection parameters 
    public Connection getcon() throws SQLException
        {
            con=DriverManager.getConnection(Url, Username, Passwword);
            return con;
        }
    //fucntion to get the Drive of the database being used 
    public void GetDrive() throws ClassNotFoundException
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
   
    // Connect to the database
    public void connection() throws ClassNotFoundException, SQLException
            {   
                GetDrive();
                getcon();
                Stmt=getcon().createStatement();
            }
      
      
      
    
    /*
     * Insert data into the database
     * @param string name of the table
     * @param Map the Data for inserting into the table
     */
     public  boolean Insert (String Table, Map Data) throws SQLException, ClassNotFoundException
      {
          String Columns=""; 
          String Values =""; 
          int i=0;           
                            
          String pre=" ";
          if (!Data.isEmpty())
            {
                Set <String> keys = Data.keySet();
                for(String key: keys) 
                {
                   pre  =(i>0)?" , ":" ";
                    Columns += pre+key;
                    Values  +=pre+"'"+Data.get(key)+"'";   
                    i++;
                }
                 SQL= "insert into "+Table+" ("+Columns+") values ("+Values+") ";
                 connection();
                    psmt=getcon().prepareStatement(SQL);
                 if (psmt.executeUpdate()>0)
                    {
                     return true;
                    }
                 else return false ;
                
             }
               return false ;
      }
     
     
     /*
     * Update data into the database
     * @param string name of the table
     * @param Map the data for updating into the table
     * @param Map where condition on updating data
     */
  public  boolean Update  (String Table, Map Data, Map Conditions ) throws SQLException, ClassNotFoundException
      {
          String ColValSet=""; 
          String WhereSql ="  where   ";
          int i=0; 
          String pre=" ";
          if (!Data.isEmpty())
            {
                Set <String> keys = Data.keySet();
                for(String key: keys) 
                {
                   pre  =(i>0)?" , ":" ";
                    ColValSet += pre+key+"='"+Data.get(key)+"'";
                       
                    i++;
                }
            }
               i=0; 
                if (!Conditions.isEmpty())
                {
                Set <String> kys = Conditions.keySet();
                for(String ky: kys) 
                {
                   pre  =(i>0)?" AND ":" ";
                    WhereSql += pre+ky+"='"+Conditions.get(ky)+"'";
                      
                    i++;
                }
                }
                 SQL= " update  "+Table+" set "+ColValSet+WhereSql ;
                 connection();
                 
                  psmt=getcon().prepareStatement(SQL);
                 if (psmt.executeUpdate()>0)
                    {
                     return true;
                    }
                 return false ;
      }
   
    /*
     * Delete data from the database
     * @param string name of the table
     * @param Map  where condition on deleting data
     */ 
  
public  boolean Delete  (String Table, Map Conditions ) throws SQLException, ClassNotFoundException
      {
           String WhereSql ="  where   "; 
          int i=0; 
          String pre=" ";
            if (!Conditions.isEmpty())
                {
                Set <String> keys = Conditions.keySet();
                for(String key: keys) 
                {
                   pre  =(i>0)?" AND ":" ";
                    WhereSql += pre+key+"='"+Conditions.get(key)+"'";
                    i++;
                }
                }
                 SQL= " delete  from   "+Table+"  "+WhereSql ;
                 connection();
                 
                  psmt=getcon().prepareStatement(SQL);
                 if (psmt.executeUpdate()>0)
                    {
                     return true;
                    }               
               return false ;
      }
     
}
